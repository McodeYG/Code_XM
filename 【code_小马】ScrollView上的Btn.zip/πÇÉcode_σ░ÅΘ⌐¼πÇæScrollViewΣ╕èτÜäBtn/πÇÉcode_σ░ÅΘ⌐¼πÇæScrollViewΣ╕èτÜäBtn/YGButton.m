//
//  YGButton.m
//  https://github.com/McodeYG/-code_-ScrollView-Btn
//
//  Created by 【code_小马】简书 on 2014/12/27.
//  Copyright © 2016年 【code_小马】简书. All rights reserved.
//

#import "YGButton.h"

@implementation YGButton

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesCancelled:touches withEvent:event];
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesMoved:touches withEvent:event];
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesEnded:touches withEvent:event];
    
}
@end
