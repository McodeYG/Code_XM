//
//  _code____ScrollView__BtnTests.m
//  【code_小马】ScrollView上的BtnTests
//
//  Created by 【code_小马】简书 on 2014/12/27.
//  Copyright © 2016年 【code_小马】简书. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _code____ScrollView__BtnTests : XCTestCase

@end

@implementation _code____ScrollView__BtnTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
